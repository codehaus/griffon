@artifact.package@import java.awt.event.ActionEvent
import org.codehaus.griffon.runtime.core.AbstractGriffonService

class @artifact.name@ extends AbstractGriffonService {
    def serviceMethod():Unit = println("Griffon")
}
