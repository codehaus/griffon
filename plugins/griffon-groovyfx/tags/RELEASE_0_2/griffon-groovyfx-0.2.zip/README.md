Griffon GroovyFX Plugin
=====================

This plugin allows you to use ithe GroovyFX library with the Griffon
framework.

*This plugin is highly experimental*
