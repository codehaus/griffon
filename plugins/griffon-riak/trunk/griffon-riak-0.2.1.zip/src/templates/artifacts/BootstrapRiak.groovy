import com.basho.riak.client.raw.RawClient

class BootstrapRiak {
    def init = { RawClient riak -> 
    }

    def destroy = { RawClient riak ->
    }
} 
