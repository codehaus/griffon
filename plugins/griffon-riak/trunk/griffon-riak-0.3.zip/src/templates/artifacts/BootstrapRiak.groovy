import com.basho.riak.client.RiakClient

class BootstrapRiak {
    def init = { String clientName, RiakClient riak -> 
    }

    def destroy = { String clientName, RiakClient riak ->
    }
} 
