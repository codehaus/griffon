griffon.project.dependency.resolution = {
    repositories {
        flatDir(name: 'plugin spring-0.9', dirs: [
            "${pluginDirPath}/dist"
        ])
    }

    dependencies {
        compile(group: 'org.codehaus.griffon.plugins', name: 'griffon-spring', version: '0.9', classifier: 'runtime')
        
    }
}