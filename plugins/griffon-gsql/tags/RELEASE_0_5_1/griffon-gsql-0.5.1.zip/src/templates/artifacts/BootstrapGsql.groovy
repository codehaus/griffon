import groovy.sql.Sql

class BootstrapGsql {
    def init = { Sql sql ->
    }

    def destroy = { Sql sql ->
    }
} 
