import groovy.sql.Sql

class BootStrapGsql {
    def init = { Sql sql ->
    }

    def destroy = { Sql sql ->
    }
} 
