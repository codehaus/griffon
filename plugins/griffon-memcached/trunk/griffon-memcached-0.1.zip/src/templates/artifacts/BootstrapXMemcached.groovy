import net.rubyeye.xmemcached.MemcachedClient

class BootstrapXMemcached {
    def init = { MemcachedClient mcc ->
    }

    def destroy = { MemcachedClient mcc ->
    }
} 
