import net.spy.memcached.MemcachedClient

class BootstrapMemcached {
    def init = { String clientName, MemcachedClient client ->
    }

    def destroy = { String clientName, MemcachedClient client ->
    }
} 
