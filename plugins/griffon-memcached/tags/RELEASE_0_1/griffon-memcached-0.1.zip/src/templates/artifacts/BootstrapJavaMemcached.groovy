import com.danga.MemCached.MemCachedClient

class BootstrapJavaMemcached {
    def init = { MemCachedClient mcc ->
    }

    def destroy = { MemCachedClient mcc ->
    }
} 
