@artifact.package@import org.uispec4j.*
import griffon.uispec4j.GriffonUISpecTestCase

class @artifact.name@ extends GriffonUISpecTestCase {
    void testSomething() {
        // Window window = getMainWindow() 
    }
 
    // protected void onSetUp() {
    // }
 
    // protected void onTearDown() {
    // }
 
    // protected UISpecAdapter initAdapter() {
    // }
}
