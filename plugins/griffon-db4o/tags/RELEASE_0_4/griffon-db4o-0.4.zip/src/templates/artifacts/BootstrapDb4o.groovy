import com.db4o.ObjectContainer

class BootstrapDb4o {
    def init = { ObjectContainer db -> 
    }

    def destroy = { ObjectContainer db ->
    }
} 
