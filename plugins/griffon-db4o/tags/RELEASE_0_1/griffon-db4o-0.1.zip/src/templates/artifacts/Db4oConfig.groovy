dataSource {
}
environments {
    development {
        dataSource {
            name = "devDb.yarv"
        }
    }
    test {
        dataSource {
            name = "testDb.yarv"
        }
    }
    production {
        dataSource {
            name = "prodDb.yarv"
        }
    }
}
