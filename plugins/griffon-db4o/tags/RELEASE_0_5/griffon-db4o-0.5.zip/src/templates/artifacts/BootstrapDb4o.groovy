import com.db4o.ObjectContainer

class BootstrapDb4o {
    def init = { String dataSourceName, ObjectContainer db -> 
    }

    def destroy = { String dataSourceName, ObjectContainer db ->
    }
} 
