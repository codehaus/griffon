@artifact.package@import org.fest.swing.fixture.*
import griffon.fest.FestSwingTestCase

class @artifact.name@ extends FestSwingTestCase {
    // instance variables:
    // app    - current application
    // window - value returned from initWindow()
    //          defaults to app.windowManager.windows[0]
 
    void testSomething() {
 
    }
 
    // protected void onSetUp() {
    // }
 
    // protected void onTearDown() {
    // }
 
    // protected FrameFixture initWindow() {
    //    return new FrameFixture(app.windowManager.windows[0])
    // }
}
