@artifact.package@class @artifact.name@ {
    final Closure routes = {
        get('/') {
            'Hello from @artifact.name@'
        }
    }
}
