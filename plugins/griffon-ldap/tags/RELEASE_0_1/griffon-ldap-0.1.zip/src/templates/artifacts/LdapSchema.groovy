@artifact.package@import gldapo.schema.annotation.GldapoNamingAttribute

class @artifact.name@ {
    @GldapoNamingAttribute
    String cn
}
