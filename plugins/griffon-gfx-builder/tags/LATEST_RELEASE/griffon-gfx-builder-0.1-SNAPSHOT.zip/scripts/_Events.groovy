import org.codehaus.griffon.cli.GriffonScriptRunner as GSR
import org.codehaus.griffon.plugins.GriffonPluginUtils

eventPackagePluginStart = { pluginName, plugin ->
    def destFileName = "lib/griffon-${pluginName}-addon-${plugin.version}.jar"
    ant.delete(dir: destFileName, quiet: false, failOnError: false)
    ant.jar(destfile: destFileName) {
        fileset(dir: classesDirPath) {
            exclude(name:'_*.class')
            exclude(name:'*GriffonPlugin.class')
        }
    }
}

eventCopyLibsEnd = { jardir ->
    def gfxlibs = "${getPluginDirForName('gfx').file}/lib"
    ant.fileset(dir: gfxlibs, includes: "*.jar").each {
        griffonCopyDist(it.toString(), jardir)
    }
    ["swingx","svg"].each { ext ->
        if(buildConfig.gfx?."$ext"?.enabled ?: false) {
            ant.fileset(dir: "${gfxlibs}/$ext", includes: "*.jar").each {
                griffonCopyDist(it.toString(), jardir)
            }
        }
    }
}

getPluginDirForName = { String pluginName ->
    // pluginsHome = griffonSettings.projectPluginsDir.path
    GriffonPluginUtils.getPluginDirForName(pluginsHome, pluginName)
}
