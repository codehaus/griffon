import terrastore.client.TerrastoreClient

class BootstrapTerrastore {
    def init = { String clientName, TerrastoreClient client -> 
    }

    def destroy = { String clientName, TerrastoreClient client ->
    }
} 
