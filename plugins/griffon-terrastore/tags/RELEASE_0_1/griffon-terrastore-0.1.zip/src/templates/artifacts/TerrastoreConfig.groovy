client {
}
environments {
    development {
        client {
            host = 'http://localhost:8080'
        }
    }
    test {
        client {
            host = 'http://localhost:8080'
        }
    }
    production {
        client {
            host = 'http://localhost:8080'
        }
    }
}
