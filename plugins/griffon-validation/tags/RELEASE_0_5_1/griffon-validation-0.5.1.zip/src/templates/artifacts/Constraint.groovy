@artifact.package@class @artifact.name@ {

    /**
     * Generated message
     *
     * @param propertyValue value of the property to be validated
     * @param bean object owner of the property
     * @param parameter configuration parameter for the constraint
     * @return true if validation passes otherwise false
     */
    def validate(propertyValue, bean, parameter) {
        // insert your custom constraint logic
    }

}