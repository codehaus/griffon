
class TwitterGriffonPlugin {

	def version = "0.1"
    def griffonVersion = '0.9.2-rc1 > *' 
    def dependsOn = [:]
    def pluginIncludes = []
    def license = 'Apache 2.0'    
    def toolkits = [] // Valid values are: swing, javafx, swt, pivot, gtk
    def platforms = []    // linux, linux64, windows, windows64, macosx, macosx64, solaris
    def author = 'Mario García'
    def authorEmail = ''
    def title = 'Twitter Plugin'
    def description = '''
		
	'''
    def documentation = 'http://griffon.codehaus.org/Twitter+Plugin'
}
