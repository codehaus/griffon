@artifact.package@class @artifact.name@ {
    final Closure routes = {
        // example:
        // from('seda:input').to('stream:out')
    }
}
