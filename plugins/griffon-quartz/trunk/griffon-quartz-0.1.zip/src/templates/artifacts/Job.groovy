@artifact.package@
class @artifact.name@ {
    static triggers = {
        // fire every 30 seconds
        cron name: '@artifact.name@', cronExpression: "30 * * * * ?"
    }

    def group = "MyGroup"

    def execute() { println "Job @artifact.name@: ping!" } 
}
