/*
 * Copyright 2009-2010 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package griffon.pivot.adapters
 
import griffon.pivot.impl.BuilderDelegate
import org.apache.pivot.wtk.Frame
import org.apache.pivot.wtk.MenuBar
import org.apache.pivot.wtk.FrameListener

/**
 * @author Andres Almiray
 */
class FrameListenerAdapter extends BuilderDelegate implements FrameListener {
    private Closure onMenuBarChanged
 
    FrameListenerAdapter(FactoryBuilderSupport builder) {
        super(builder)
    }

    void onMenuBarChanged(Closure callback) {
        onMenuBarChanged = callback
        onMenuBarChanged.delegate = this
    }

    void menuBarChanged(Frame arg0, MenuBar arg1) {
        if(onMenuBarChanged) onMenuBarChanged(arg0, arg1)
    }
}