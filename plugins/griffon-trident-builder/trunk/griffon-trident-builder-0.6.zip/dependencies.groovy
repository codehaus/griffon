griffon.project.dependency.resolution = {
    inherits("global")
    log "warn"
    repositories {
        griffonPlugins()
        griffonHome()
        griffonCentral()
        flatDir name: 'tridentBuilderPluginLib', dirs: 'lib'
    }
    dependencies {
        build   'org.codehaus.griffon:tridentbuilder:0.4',
                'org.pushingpixels:trident:1.3'
        compile 'org.codehaus.griffon:tridentbuilder:0.4',
                'org.pushingpixels:trident:1.3'
    }
}

griffon {
    doc {
        logo = '<a href="http://griffon.codehaus.org" target="_blank"><img alt="The Griffon Framework" src="../img/griffon.png" border="0"/></a>'
        sponsorLogo = "<br/>"
        footer = "<br/><br/>Made with Griffon (@griffon.version@)"
    }
}

griffon.jars.destDir='target/addon'
griffon.plugin.pack.additional.sources = ['src/gdsl']
