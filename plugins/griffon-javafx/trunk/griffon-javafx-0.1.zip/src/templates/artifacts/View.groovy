@artifact.package@
stackPane {
    text(text: bind(model.messageProperty))
}
