Griffon JavaFX Plugin
=====================

This plugin allows you to create JavaFX 2.0 applications with the Griffon
framework.

*This plugin is highly experimental*
