slide(id: '@name@', title: '@name@') {
    migLayout(layoutConstraints: 'fill',
              columnConstraints: '[center]',
              rowConstraints: '[center]')
    label("Insert your text here")
}
