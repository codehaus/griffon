== What is Airbag Plugin  ==

Airbag plugin provides a simple and user friendly exception dialog 
component that can be used in combination with Griffon 
UncaughtExceptionThrown event to report any unhandled exception.


== For more Information ==

Check out our WIKI page: http://griffon.codehaus.org/Airbag+Plugin
