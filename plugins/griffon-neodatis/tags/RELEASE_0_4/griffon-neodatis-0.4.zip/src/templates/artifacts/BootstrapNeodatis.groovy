import org.neodatis.odb.ODB

class BootstrapNeodatis {
    def init = { String databaseName, ODB odb -> 
    }

    def destroy = { String databaseName, ODB odb ->
    }
} 
