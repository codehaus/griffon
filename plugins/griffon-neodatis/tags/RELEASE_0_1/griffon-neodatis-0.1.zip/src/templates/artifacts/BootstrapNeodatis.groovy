import org.neodatis.odb.ODB

class BootstrapNeodatis {
    def init = { ODB odb -> 
    }

    def destroy = { ODB odb ->
    }
} 
