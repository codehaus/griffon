msn {
    messenger {
        username = ''
        password = ''
        logInput = true
        logOutput = true
        initialStatus = 'ONLINE'
    }
    listeners {
        contactList = []
        email = []
        fileTransfer = []
        message = []
        messenger = []
        switchboard = []
    }
}
