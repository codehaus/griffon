@artifact.package@import java.io.Serializable

class @artifact.name@ implements Serializable {
    int id
    String name
}
