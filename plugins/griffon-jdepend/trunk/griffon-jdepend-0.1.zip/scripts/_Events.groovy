eventCleanEnd = {
    Ant.delete(dir: "${projectWorkDir}/jdepend-classes", failonerror: false)
}
