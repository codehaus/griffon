eventCleanEnd = {
    ant.delete(dir: "${projectWorkDir}/jdepend-classes", failonerror: false)
}
