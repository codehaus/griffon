import com.amazon.carbonado.Repository

class BootstrapCarbonado {
    def init = { Repository repository ->
    }
    def destroy = { Repository repository ->
    }
} 
