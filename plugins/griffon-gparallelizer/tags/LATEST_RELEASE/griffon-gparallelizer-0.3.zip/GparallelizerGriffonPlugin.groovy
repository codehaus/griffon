class GparallelizerGriffonPlugin {
    def version = 0.3
    def canBeGlobal = false
    def dependsOn = [:]

    // TODO Fill in these fields
    def author = "Vaclav Pech"
    def authorEmail = ""
    def title = "GParallelizer Plugin"
    def description = '''\\
Adds GParallelizer jar files to the projects. More on GParallelizer at http://code.google.com/p/gparallelizer/
'''

    // URL to the plugin's documentation
    def documentation = "http://griffon.codehaus.org/Gparallelizer+Plugin"

}
