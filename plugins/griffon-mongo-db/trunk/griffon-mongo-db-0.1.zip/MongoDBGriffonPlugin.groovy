class MongoDBGriffonPlugin {
    def version = 0.1
    def canBeGlobal = false
    def dependsOn = [guice:0.1]

    // TODO Fill in these fields
    def author = "Your name"
    def authorEmail = ""
    def title = "Plugin summary/headline"
    def description = '''\\
Brief description of the plugin.
'''

    // URL to the plugin's documentation
    def documentation = "http://griffon.codehaus.org/MongoDB+Plugin"
}
