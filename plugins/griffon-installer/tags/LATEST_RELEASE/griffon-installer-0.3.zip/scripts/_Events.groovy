eventCleanEnd = {
    // Ant.delete(dir: "${basedir}/installer/", failonerror: false)
}
