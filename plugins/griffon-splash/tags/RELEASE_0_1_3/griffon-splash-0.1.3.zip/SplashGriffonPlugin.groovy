class SplashGriffonPlugin {
    def version = '0.1.3'
    def canBeGlobal = false
    def dependsOn = [:]

    // TODO Fill in these fields
    def author = "Jim Shingler"
    def authorEmail = "ShinglerJim@gmail.com"
    def title = "A Griffon Splash Screen Plugin"
    def description = '''\\
A Griffon Splash Screen Plugin
'''

    // URL to the plugin's documentation
    def documentation = "http://griffon.codehaus.org/Splash+Plugin"
}
