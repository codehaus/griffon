class EasybGriffonPlugin {
    def version = 'trunk'
    def canBeGlobal = true
    def dependsOn = [:]

    def author = "Andres Almiray"
    def authorEmail = "aalmiray@users.sourceforge.net"
    def title = "Enables BDD testing with Easyb"
    def description = '''\
Enables BDD testing with Easyb (http://easyb.org)
'''

    def documentation = "http://griffon.codehaus.org/Easyb+Plugin"
}
