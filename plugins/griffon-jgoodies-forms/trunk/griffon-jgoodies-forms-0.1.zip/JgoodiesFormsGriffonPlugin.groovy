class JgoodiesFormsGriffonPlugin {
    def version = 0.1
    def canBeGlobal = true
    def dependsOn = [:]

    def author = "Andres Almiray"
    def authorEmail = "aalmiray@users.sourceforge.net"
    def title = "JGoodies Forms"
    def description = '''\\
Enables the usage of JGoodies FormLayout and friends
'''

    // URL to the plugin's documentation
    def documentation = "http://griffon.codehaus.org/JgoodiesForms+Plugin"
}
