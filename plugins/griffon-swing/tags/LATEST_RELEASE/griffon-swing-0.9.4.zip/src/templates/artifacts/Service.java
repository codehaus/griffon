@artifact.package@import org.codehaus.griffon.runtime.core.AbstractGriffonService;

public class @artifact.name@ extends AbstractGriffonService {
    public void serviceMethod() {

    }
}
