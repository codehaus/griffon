@artifact.package@import org.neo4j.graphdb.RelationshipType;

public enum @artifact.name@ implements RelationshipType {
    // Fill in with your own relationship constants
}
