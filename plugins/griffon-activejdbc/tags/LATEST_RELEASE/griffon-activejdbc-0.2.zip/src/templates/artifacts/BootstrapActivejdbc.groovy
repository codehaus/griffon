class BootstrapActivejdbc {
    def init = { String dataSourceName ->
    }

    def destroy = { String dataSourceName ->
    }
} 
