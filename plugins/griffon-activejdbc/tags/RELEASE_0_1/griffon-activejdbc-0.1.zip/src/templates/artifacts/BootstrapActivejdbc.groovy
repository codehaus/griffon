class BootstrapActivejdbc {
    def init = { ->
    }

    def destroy = { ->
    }
} 
