import com.sleepycat.je.Environment

class BootstrapBerkeleydb {
    def init = { Environment env -> 
    }

    def destroy = { Environment env ->
    }
} 
