@artifact.package@import griffon.spock.*

class @artifact.name@ extends UnitSpec {
    def 'my first unit spec'() {
        expect:
            1 == 1
    }
}
