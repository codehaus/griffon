@artifact.package@import spock.lang.*

class @artifact.name@ extends Specification {
    def 'my first unit spec'() {
        expect:
            1 == 1
    }
}
