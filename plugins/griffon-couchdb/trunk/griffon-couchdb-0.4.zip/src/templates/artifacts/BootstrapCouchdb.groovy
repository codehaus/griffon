import org.jcouchdb.db.Database

class BootstrapCouchdb {
    def init = { Database db -> 
    }

    def destroy = { Database db ->
    }
} 
