import org.jcouchdb.db.Database

class BootstrapCouchdb {
    def init = { Database db, String databaseName -> 
    }

    def destroy = { Database db, String databaseName ->
    }
} 
